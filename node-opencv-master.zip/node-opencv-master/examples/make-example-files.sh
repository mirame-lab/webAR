mencoder examples/motion.mov -ovc raw -vf format=i420 -nosound -o  examples/motion.avi
